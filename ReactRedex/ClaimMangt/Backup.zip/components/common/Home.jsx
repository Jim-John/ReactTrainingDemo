import React from 'react';
import Menu from './Menu.jsx';

class Home extends React.Component {
    render() {
       return (
          <div>
             <Menu/>
             <h4>Home Page</h4>
          </div>
       )
    }
 }
  
 export default Home ;
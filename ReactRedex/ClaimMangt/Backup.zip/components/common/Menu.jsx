import React from 'react';
import Nav from 'react-bootstrap/Nav';
import { Router, Route, Link, browserHistory, IndexRoute  } from 'react-router';
import UserDetails from './UserDetails.jsx';
import Navbar from 'react-bootstrap/Navbar'

class Menu extends React.Component {

  render() {
    return (
      <div>
      
		
        <Navbar bg="light" variant="light">
    <Navbar.Brand >Welcome</Navbar.Brand>
    <Nav className="navbar navbar-expand ">
      <Nav.Link href="#home" as={Link} to="home">Home</Nav.Link>
      <Nav.Link href="#claim" as={Link} to="claim">Claim Summary</Nav.Link>
      <Nav.Link eventKey="ilink-3">About</Nav.Link>
      <Nav.Link eventKey="ilink-4">Contact</Nav.Link>
    </Nav>
    <div>
    </div>
</Navbar>


        {this.props.children}
      </div>
	  
	    
    )
  }
}
export default Menu;
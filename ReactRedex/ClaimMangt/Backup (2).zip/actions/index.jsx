export const loggedInIndicatorAction = ()=>
{
 return 
 {
     type:'SIGN_IN'
 };

}
export const loggedInUserNameAction = ()=>
{
 return 
 {
     type:'LOGGEDIN_USER'
 };
 
}
export const loggedInDateAction = ()=>
{
 return 
 {
     type:'LOGGEDIN_DATE'
 };
 
}
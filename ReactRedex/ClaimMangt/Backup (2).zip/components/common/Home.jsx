import React from 'react';
import Navigation from './Navigation.jsx';

class Home extends React.Component {
    render() {
       return (
          <div>
             <Navigation/>
             <h4>Home Page</h4>
          </div>
       )
    }
 }
  
 export default Home ;
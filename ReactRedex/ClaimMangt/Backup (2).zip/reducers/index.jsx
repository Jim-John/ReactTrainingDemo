import loggedInDateReducer from './loggedInDate.jsx';
import loggedInIndicatorReducer from './loggedInIndicator.jsx';
import loggedInNameReducer from './loggedInName.jsx';
import { combineReducers} from 'redux';
const allReducers=combineReducers(
    {
        loggedInDateReducer:loggedInDateReducer,
        loggedInNameReducer:loggedInNameReducer,
        loggedInIndicatorReducer:loggedInIndicatorReducer

    }
)
export default allReducers;
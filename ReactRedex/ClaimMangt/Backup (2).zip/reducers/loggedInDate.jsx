const loggedInDateReducer=(state='08-21-2020',action) =>{
    switch (action.type) 
    {
       case 'LOGGEDIN_DATE':
                            {   var dt = new Date();
                                (("0"+dt.getDate()).slice(-2)) +"."+ 
                                (("0"+(dt.getMonth()+1)).slice(-2)) +"."+ (dt.getFullYear()) +" "+ (("0"+dt.getHours()).slice(-2)) +
                                ":"+ (("0"+dt.getMinutes()).slice(-2))
                                return dt
                            }
                            ;
                default   :return '08-21-2020' ;
    }
   
}
export default loggedInDateReducer;
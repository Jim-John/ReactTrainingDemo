const loggedInNameReducer=(state='anonymous ',action) =>{
    switch (action.type) 
    {
       case 'LOGGEDIN_USER':return state;
                default   :return 'anonymous' ;
    }
    
}
export default loggedInNameReducer;
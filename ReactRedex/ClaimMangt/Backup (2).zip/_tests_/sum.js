const { __esModule } = require("react-router/lib/RouteUtils");

function sum(a,b)
{
    return a+b;
}
module.exports=sum;